#include "stdio.h"
#include <stdlib.h>
#include "FileOpsStudent2.h"
void search_title();
void search_author();
//void search_author();
//void search_year();
//void display_publications();


int main() {
  ReadDataFile();
  int choice;
  while (choice != 5) {

    printf("\t\t\t=====Bibliography=====");
    printf("\n\n\n\t\t\t\t     1. Search by Title\n");
    printf("\t\t\t\t     2. Search by Author's surname\n");
    printf("\t\t\t\t     3. Search by Year\n");
    printf("\t\t\t\t     4. Display Publications\n");
    printf("\t\t\t\t     5. Exit\n");
    printf("\t\t\t\t    _____________________\n");
    printf("\t\t\t\t     ");
    scanf("%d", &choice);

    switch (choice) {
    case 1:
      system("cls");
      search_title();
      printf("\t\t\t\t  press any key to exit..... \n");
      getchar();
      system("cls");
      break;
    case 2:
      system("cls");
      search_author();
      printf("\t\t\t\t  press any key to exit..... \n");
      getchar();
      system("cls");

      break;

    case 3:
      system("cls");
      search_year();
      printf("\n\t\t\t\t  Press any key to exit.......\n");
      getchar();
      system("cls");

      break;

    case 4:
      system("cls");
      display_publications();
      printf("\n\t\t\t\tPress any key to exit.......\n");
      getchar();
      system("cls");
      break;
    case 5:
      system("cls");
      printf("\n\t\t\t\tThank you\n\n");
      exit(0);
      break;

    default:
      system("cls");
      getchar();
      printf("\n\t\t\t\t\tEnter a valid number\n\n");
      printf("\t\t\t\tPress any key to continue.......");
      getchar();
      system("cls");
      break;
    }
  }

  getchar();
}

// void search_title() {
//   char another;
  
//   do {
    

//     printf("\t\t\tYou want to search for another record?(y/n) : ");

//     scanf("%s", &another);

//   } while (another == 'y' || another == 'Y');
// }

