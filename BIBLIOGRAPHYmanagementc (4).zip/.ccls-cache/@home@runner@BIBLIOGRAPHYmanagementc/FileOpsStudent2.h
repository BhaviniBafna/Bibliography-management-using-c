//
///
// Created by khem1_000 on 29/07/2020.
//

#ifndef BIBLIORESIT_FILEOPSSTUDENT_H
#define BIBLIORESIT_FILEOPSSTUDENT_H

//header files
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
//#include <unistd.h>
//#include <ctype.h>
#include <string.h>

//defines
#define MYPATH  "C:/bibliography/details" 

//global variables
//FILE *ptr;

//Arrays to read Biblio file
//char TitleArr[30][100];
//int YearArr[30];
//char AuthorArr[30][100];
//char TypeArr[30][50];


//prototypes
void ReadDataFile();
//void display_publications();


#endif //BIBLIORESIT_FILEOPSSTUDENT_H
