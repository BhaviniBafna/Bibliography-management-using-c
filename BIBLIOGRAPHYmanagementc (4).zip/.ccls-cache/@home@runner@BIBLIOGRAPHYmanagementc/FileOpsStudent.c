

#include "FileOpsStudent2.h"
FILE *ptr;

char TitleArr[30][100];
int YearArr[30];
char AuthorArr[30][100];
char TypeArr[30][50];

char a[400], bf[400], c[400], d[400]; // variables
int i=0, k = 0, flag = -1;
int count=0;
void word_search();

#define FOUND 1
#define NOTFOUND 0

struct bibliography {
  char TitleArr[30][100];
  int YearArr[30];
  char AuthorArr[30][100];
  char TypeArr[30][50];

} b[30];

void linkfloat() {
  float a = 0, *b;
  b = &a;
  a = *b;
}

// displaying all the stored data in array of structures
void display_all(struct bibliography *sp) {
  printf("Title: %s\nAuthor: %s\nYear: %s\nType: %s\n", sp->TitleArr,
         sp->AuthorArr, sp->YearArr, sp->TypeArr);
}

void display_publications() {
  int conference, c_count = 0;
  int journal, j_count = 0;
  int book, b_count = 0;

  for (int i = 0; i < 30; i++) {
    conference = strcmp(b[i].TypeArr, "Conference");
    journal = strcmp(b[i].TypeArr, "Journal");
    book = strcmp(b[i].TypeArr, "Book");
    if (conference == 0) {
      c_count++;
    } else {
      if (journal == 0) {
        j_count++;
      } else {
        b_count++;
      }
    }
  }
  printf("\nNumber of Conferences: %d", c_count);
  printf("\nNumber of Journals: %d", j_count);
  printf("\nNumber of Books: %d", b_count);
  getchar();
}

void search_year() {
  char year[5];
  printf(" enter the year");
  scanf("%s", &year);
  for (int i = 0; i < 30; i++) {
    if (strcmp(b[i].YearArr, year) == 0) {
      printf("\nTitle: %s\nAuthor: %s\nYear: %s\nType: %s\n", b[i].TitleArr,
             b[i].AuthorArr, b[i].YearArr, b[i].TypeArr);
      printf("------------------------------------------------\n");
    }
  }
}

void word_search() {
   //printf("\n%s",a);
   i=0;
   k=0;
   flag=-1;
  // printf("\n inside %s", a);
  while (a[i] != '\0') {
    // loop for checking blank space/null character
    while (i < strlen(a)) {
      if (a[i] == ' ' || a[i] == '.' || a[i] == '\0')
        break;
      c[k++] = a[i++]; // copying elements to third array
    }
    c[k] = '\0'; // assigning null character to third array
    k = 0;

    // comparing each word of sentence with word to search
    //printf("\nb= %s\nc=%s", bf, c);
    if (strcmp(bf, c) == 0)
      flag = 1; // if word matched,assigning true value to flag
    i++;
  }
  
  
}

void search_title() {
  fflush(stdin);
  printf("Enter the word:\n");
  scanf("%s", &bf); // input word to search
  int count=0;
  while(count < 30) {
    strcpy(a, TitleArr[count]);
    word_search();
    //printf("\n%d", flag);
    if(flag==1){
      printf("\nTitle: %s\nAuthor: %s\nYear: %s\nType: %s\n", b[count].TitleArr,
             b[count].AuthorArr, b[count].YearArr, b[count].TypeArr);
      printf("------------------------------------------------\n");
    }
    count=count+1;
    
  }
}


void search_author() {
  fflush(stdin);
  printf("Enter the word:\n");
  scanf("%s", &bf); // input word to search
  int count=0;
  while(count < 30) {
    strcpy(a, AuthorArr[count]);
    word_search();
    //printf("\n%d", flag);
    if(flag==1){
      printf("\nTitle: %s\nAuthor: %s\nYear: %s\nType: %s\n", b[count].TitleArr,
             b[count].AuthorArr, b[count].YearArr, b[count].TypeArr);
      printf("------------------------------------------------\n");
    }
    count=count+1;
    
  }
}





void ExtractSub(char *Dat, char *subs) {
  char *subString;

  subString = strtok(Dat, "{");
  subString = strtok(NULL, "}");

  strcpy(subs, subString);
}

void ReadDataFile() {
  int t = 0, offset = 0;
  char src[100] = "";
  size_t len = 0;
  char line[1024];
  char subs[256] = "";
  int Yr;

  // strcat( strcat(src, MYPATH), location);
  // open file for reading
  ptr = fopen("BiblioFile.txt", "r");

  if (ptr == NULL) {
    printf("Error!\n");
    exit(1);
  } else
    printf("Success!\n");

  int count = 0, cnt = 0, s = 0;
  while (fgets(line, sizeof(line), ptr)) {

    switch (offset) {
    case 0:
      ExtractSub(line, subs);
      strcpy(b[t].TitleArr, subs);
      strcpy(TitleArr[t], subs);
      offset++;
      break;
    case 1:
      offset++;
      ExtractSub(line, subs);
      strcpy(b[t].AuthorArr, subs);
      strcpy(AuthorArr[t], subs);
      break;
    case 2:
      offset++;
      ExtractSub(line, subs);
      // b[t].YearArr= atoi(subs);
      strcpy(b[t].YearArr, subs);
      YearArr[t] = atoi(subs);
      break;
    case 3:
      ExtractSub(line, subs);
      strcpy(b[t].TypeArr, subs);
      strcpy(TypeArr[t], subs);
      offset = 0;
      t++;
      break;
    }

    printf("%s\n", subs);

    ++count;
    if (count % 4 == 0) {
      ++cnt;
      printf("%d", cnt);
    }

    memset(subs, 0, sizeof(subs));
    memset(line, 0, sizeof(line));
  }

  fclose(ptr);
  system("cls");
  printf(" saving done\n");
  // printf("enter type of publication to search");
  // scanf("%s", &type);

  for (int i = 0; i < 30; i++) {
    display_all(&b[i]);
  }
}